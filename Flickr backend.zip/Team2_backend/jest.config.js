module.exports = {
    testEnvironment: 'node',
}
