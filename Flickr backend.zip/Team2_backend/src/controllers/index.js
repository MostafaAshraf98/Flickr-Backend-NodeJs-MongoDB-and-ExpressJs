exports.favsController = require('./favs.controller')
